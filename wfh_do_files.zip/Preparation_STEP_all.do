/********************************************************************

Project: Jobs' Amenability to Working from Home: Evidence from Skills 
Surveys for 53 countries

This do files: Prepares STEP database

*********************************************************************/

clear all
set more off

****************************************************************************
*Round 1. Countries* Bolivia Colombia Laos Vietnam Ukraina SriLanka

********************************************************
*1. Data Clean-Up*
foreach x in BOL COL LAO VNM LKA UKR {

use "C:\Users\Jobs\COVID\STEP\STEP_`x'", clear// replace the folder name
*******************************************************

*Keeping Workers who Were Employed in the Past Twelve Months*
keep if emplast12 == 1 

*Renaming Variables*
rename m4c_q06 emptype_current
rename m4a_q25 emptype_previous

*Drop workers in military occupations*
drop if occupation == 0

*Two-Digit Occupation*
gen occ2 = floor(occupationcode/10)

*Change the weight add up to 100
 egen total=total( W_FinSPwt)
 g W_FinSPwt_100= W_FinSPwt/total*100

********************************************************
*2. Task Characterization*
********************************************************
*1. Lifted Anything more than 50 Pounds* 											
gen  physical_manual1=1 if m5b_q02==1
replace  physical_manual1=0 if m5b_q02==2
replace physical_manual1=. if physical_manual1==. |physical_manual1<0

*Using any number from 1 to 10 where 1 is not at all physically demanding (such as sitting at a desk answering a telephone) and 10 is extremely physically demanding (such as carrying heavy loads, construction worker, etc), what number would you use to rate how physically demanding your work is? 											
gen  physical_manual2=m5b_q03
replace physical_manual2=. if physical_manual2==. |physical_manual2<0 |physical_manual2>10

*2. Drive a car, truck or three-wheeler?																	
gen  physical_manual3=1 if  m5b_q06 ==1
replace  physical_manual3=0 if  m5b_q06 ==2
replace physical_manual3=. if physical_manual3==. |physical_manual3<0

*3. Repair/maintain electronic equipment? (cell phones, computers, printers, other electronic equipment...)																		
gen  physical_manual4=1 if  m5b_q07 ==1
replace  physical_manual4=0 if  m5b_q07 ==2
replace physical_manual4=. if physical_manual4==. |physical_manual4<0

*4. Operate or work with any heavy machines or industrial equipment ?  For example, machines/equipment in factories, construction sites, warehouses, repair shops or machine shops, industrial kitchens, some farming ( tractors, harvesters, milking machine).																	
gen  physical_manual5=1 if  m5b_q08 ==1
replace  physical_manual5=0 if  m5b_q08 ==2
replace physical_manual5=. if physical_manual5==. |physical_manual5<0

*5. Face to face
*Time/contact involved with non-coworkers/customers*															
*Using any number from 1 to 10, where 1 is little involvement or short routine involvements, and 10 means much of the work involves meeting or interacting for at least 10-15 minutes at a time with a customer, client, student or the public, what number would you use to rate this work?																	
gen contact1 =m5b_q05
replace contact1 =0 if  m5b_q04 ==2
replace contact1=. if contact1==. |contact1<0 |contact1>10

gen contact_important = 1 if contact1 == 9 | contact1 ==10


*6. Direct and check the work of other workers (supervise)?												
gen contact2 =1 if  m5b_q11 ==1
replace contact2 =0 if  m5b_q11 ==2
replace contact2=. if contact2==. |contact2<0

* ICT use
* 7. Use telephone
gen  ict1=1 if  m5b_q13_1 ==1
replace  ict1=0 if  m5b_q13_1 ==2
replace ict1=. if ict1==. |ict1<0

* 8. Intensity of computer use										
gen  ict2= 1 if m5b_q17 ==4
replace  ict2= 2 if m5b_q17 ==3
replace  ict2= 3 if m5b_q17 ==2
replace  ict2= 4 if m5b_q17 ==1
replace  ict2=0 if  m5b_q16 ==2
replace ict2=. if ict2==. |ict2<0

*9. Not have internet at home
gen ict3=1 if m1b_q15_9==2
replace ict3=0 if m1b_q15_9==1
replace ict3=. if ict3==. |ict3<0

keep cluster  W_FinSPwt occupation occupationcode occ2 hh_size urban age earnings_h ln_earnings_h permanent pub_emp ict3 ict2 ict1 contact2 contact1 contact_important physical_manual5 physical_manual4 physical_manual3 physical_manual2 physical_manual1 age self_emp gender informal econ_sector occupation occupationcode country m1a_q09 W_FinSPwt_100 W_FinSPwt emptype_current emptype_previous 


save "C:\Users\Jobs\COVID\STEP\STEPv_`x'",replace
 }
 
 ****************************************************************************
*2. Round 2 Countries*Armenia Georgia Ghana Kenya Macedonia
****************************************************************************

foreach x in ARM GEO GHA KEN MKD {

use "C:\Users\Jobs\COVID\STEP\STEP_`x'", clear
 
*Keeping Workers who Were Employed in the Past Twelve Months*
keep if emplast12 == 1 

*Renaming Variables*
rename m4c_q06 emptype_current
rename m4a_q25 emptype_previous

*Drop workers in military occupations*
drop if occupation == 0



*Two-Digit Occupation*
gen occ2 = floor(occupationcode/10)



*Change the weight add up to 100
 egen total=total( W_FinSPwt)
 g W_FinSPwt_100= W_FinSPwt/total*100

********************************************************
*2. Task Characterization*
********************************************************
*1. Lifted Anything more than 50 Pounds* 											
gen  physical_manual1=1 if m5b_q02==1
replace  physical_manual1=0 if m5b_q02==2
replace physical_manual1=. if physical_manual1==. |physical_manual1<0

*Using any number from 1 to 10 where 1 is not at all physically demanding (such as sitting at a desk answering a telephone) and 10 is extremely physically demanding (such as carrying heavy loads, construction worker, etc), what number would you use to rate how physically demanding your work is? 											
gen  physical_manual2=m5b_q03
replace physical_manual2=. if physical_manual2==. |physical_manual2<0 | physical_manual2>10

*2. Drive a car, truck or three-wheeler?																	
gen  physical_manual3=1 if  m5b_q07 ==1
replace  physical_manual3=0 if  m5b_q07 ==2

replace physical_manual3=. if physical_manual3==. |physical_manual3<0

*3. Repair/maintain electronic equipment? (cell phones, computers, printers, other electronic equipment...)																		
gen  physical_manual4=1 if  m5b_q08 ==1
replace  physical_manual4=0 if  m5b_q08 ==2
replace physical_manual4=. if physical_manual4==. |physical_manual4<0

*4. Operate or work with any heavy machines or industrial equipment ?  For example, machines/equipment in factories, construction sites, warehouses, repair shops or machine shops, industrial kitchens, some farming ( tractors, harvesters, milking machine).																	
gen  physical_manual5=1 if  m5b_q09 ==1
replace  physical_manual5=0 if  m5b_q09 ==2
replace physical_manual5=. if physical_manual5==. |physical_manual5<0

*5. Face to face
*Time/contact involved with non-coworkers/customers*															
*Using any number from 1 to 10, where 1 is little involvement or short routine involvements, and 10 means much of the work involves meeting or interacting for at least 10-15 minutes at a time with a customer, client, student or the public, what number would you use to rate this work?																	
gen contact1 =m5b_q06
replace contact1 =0 if  m5b_q05 ==2
replace contact1=. if contact1==. |contact1<0 |contact1>10

gen contact_important = 1 if contact1 == 9 | contact1 ==10

*6. Direct and check the work of other workers (supervise)?												
gen contact2 =1 if  m5b_q13==1
replace contact2 =0 if  m5b_q13 ==2


replace contact2=. if contact2==. |contact2<0

* ICT use
* 7. Use telephone
gen  ict1=1 if  m5b_q15 ==1
replace  ict1=0 if  m5b_q15 ==2
replace ict1=. if ict1==. |ict1<0

* 8. Intensity of computer use										
gen  ict2= 1 if m5b_q19 ==4
replace  ict2= 2 if m5b_q19 ==3
replace  ict2= 3 if m5b_q19 ==2
replace  ict2= 4 if m5b_q19 ==1
replace  ict2=0 if  m5b_q18 ==2
replace ict2=. if ict2==. |ict2<0

*9. Not have internet at home
gen ict3=1 if m1b_q15_9==2
replace ict3=0 if m1b_q15_9==1

replace ict3=. if ict3==. |ict3<0

keep cluster  W_FinSPwt occupation occupationcode occ2 hh_size urban age earnings_h ln_earnings_h permanent pub_emp ict3 ict2 ict1 contact2 contact1 contact_important physical_manual5 physical_manual4 physical_manual3 physical_manual2 physical_manual1 age self_emp gender informal econ_sector occupation occupationcode country m1a_q09 W_FinSPwt_100 W_FinSPwt emptype_current emptype_previous 

save "C:\Users\Jobs\COVID\STEP\STEPv_`x'",replace
 }
 
****************************************************************************
*3. Round 3 Countries* Philipine Kosov Serbia
****************************************************************************

foreach x in PHL XKX SRB {

use "C:\Users\WB541523\OneDrive - WBG\Jobs\COVID\STEP\STEP_`x'", clear
 
 *Keeping Workers who Were Employed in the Past Twelve Months*
keep if emplast12 == 1 

*Renaming Variables*
rename m1a_q16 emptype_current
g emptype_previous=.

*Drop workers in military occupations*
drop if occupation == 0

*Two-Digit Occupation*
gen occ2 = floor(occupationcode/10)



*Change the weight add up to 100
 egen total=total( W_FinSPwt)
 g W_FinSPwt_100= W_FinSPwt/total*100

********************************************************
*2. Task Characterization*
********************************************************
*1. Lifted Anything more than 50 Pounds* 											
gen  physical_manual1=1 if m6b_q02==1
replace  physical_manual1=0 if m6b_q02==2

replace physical_manual1=. if physical_manual1==. |physical_manual1<0

*Using any number from 1 to 10 where 1 is not at all physically demanding (such as sitting at a desk answering a telephone) and 10 is extremely physically demanding (such as carrying heavy loads, construction worker, etc), what number would you use to rate how physically demanding your work is? 											
gen  physical_manual2=m6b_q03
replace physical_manual2=. if physical_manual2==. |physical_manual2<0 | physical_manual2>10

*2. Drive a car, truck or three-wheeler?																	
gen  physical_manual3=1 if  m6b_q07 ==1
replace  physical_manual3=0 if  m6b_q07 ==2
replace physical_manual3=. if physical_manual3==. |physical_manual3<0

*3. Repair/maintain electronic equipment? (cell phones, computers, printers, other electronic equipment...)																		
gen  physical_manual4=1 if  m6b_q08 ==1
replace  physical_manual4=0 if  m6b_q08 ==2

replace physical_manual4=. if physical_manual4==. |physical_manual4<0

*4. Operate or work with any heavy machines or industrial equipment ?  For example, machines/equipment in factories, construction sites, warehouses, repair shops or machine shops, industrial kitchens, some farming ( tractors, harvesters, milking machine).																	
gen  physical_manual5=1 if  m6b_q09 ==1
replace  physical_manual5=0 if  m6b_q09 ==2
replace physical_manual5=. if physical_manual5==. |physical_manual5<0

*5. Face to face
*Time/contact involved with non-coworkers/customers*															
*Using any number from 1 to 10, where 1 is little involvement or short routine involvements, and 10 means much of the work involves meeting or interacting for at least 10-15 minutes at a time with a customer, client, student or the public, what number would you use to rate this work?																	
gen contact1 =m6b_q06
replace contact1 =0 if  m6b_q05 ==2
replace contact1=. if contact1==. |contact1<0 |contact1>10

gen contact_important = 1 if contact1 == 9 | contact1 ==10


*6. Direct and check the work of other workers (supervise)?												
gen contact2 =1 if  m6b_q13 ==1
replace contact2 =0 if  m6b_q13 ==2
replace contact2=. if contact2==. |contact2<0

* ICT use
* 7. Use telephone
gen  ict1=1 if  m6b_q15 ==1
replace  ict1=0 if  m6b_q15 ==2
replace ict1=. if ict1==. |ict1<0

* 8. Intensity of computer use										
gen  ict2= 1 if m6b_q19 ==4
replace  ict2= 2 if m6b_q19 ==3
replace  ict2= 3 if m6b_q19 ==2
replace  ict2= 4 if m6b_q19 ==1
replace  ict2=0 if  m6b_q18 ==2
replace ict2=. if ict2==. |ict2<0

*9. Not have internet at home
gen ict3=1 if m1b_q15_9==2
replace ict3=0 if m1b_q15_9==1

replace ict3=. if ict3==. |ict3<0

keep cluster W_FinSPwt occupation occupationcode occ2 hh_size age earnings_h ln_earnings_h  permanent pub_emp  ict3 ict2 ict1 contact2 contact1 contact_important physical_manual5 physical_manual4 physical_manual3 physical_manual2 physical_manual1 age self_emp gender informal econ_sector occupation occupationcode country m1a_q09 W_FinSPwt_100 W_FinSPwt emptype_current emptype_previous 

save "C:\Users\Jobs\COVID\STEP\STEPv_`x'",replace
 } 
 ****************************************************************************
*4. Round 4 Country* Elsalvador
****************************************************************************
 foreach x in SLV {

use "C:\Users\Jobs\COVID\STEP\STEP_`x'", clear
 
 *Keeping Workers who Were Employed in the Past Twelve Months*
keep if active == 1 

*Renaming Variables*
rename employed emptype_current
rename employed2 emptype_previous

*Drop workers in military occupations*
drop if occupation == 0


*Two-Digit Occupation*
gen occ2 = floor(occupationcode/10)

*Change the weight add up to 100
 egen total=total(pond)
 g W_FinSPwt_100= pond/total*100
 rename pond W_FinSPwt

********************************************************
*2. Task Characterization*
********************************************************
*1. Lifted Anything more than 50 Pounds* 											
gen  physical_manual1=1 if m5p9==1
replace  physical_manual1=0 if m5p9==2

replace physical_manual1=. if physical_manual1==. |physical_manual1<0

*Using any number from 1 to 10 where 1 is not at all physically demanding (such as sitting at a desk answering a telephone) and 10 is extremely physically demanding (such as carrying heavy loads, construction worker, etc), what number would you use to rate how physically demanding your work is? 											
gen  physical_manual2=m5p10
replace physical_manual2=. if physical_manual2==. |physical_manual2<0 | physical_manual2>10

*2. Drive a car, truck or three-wheeler?																	
gen  physical_manual3=1 if  m5p12 ==1
replace  physical_manual3=0 if  m5p12 ==2
replace physical_manual3=. if physical_manual3==. |physical_manual3<0

*3. Repair/maintain electronic equipment? (cell phones, computers, printers, other electronic equipment...)																		
gen  physical_manual4=1 if  m5p13 ==1
replace  physical_manual4=0 if  m5p13 ==2
replace physical_manual4=. if physical_manual4==. |physical_manual4<0

*4. Operate or work with any heavy machines or industrial equipment ?  For example, machines/equipment in factories, construction sites, warehouses, repair shops or machine shops, industrial kitchens, some farming ( tractors, harvesters, milking machine).																	
gen  physical_manual5=1 if  m5p14 ==1
replace  physical_manual5=0 if  m5p14 ==2
replace physical_manual5=. if physical_manual5==. |physical_manual5<0

*5. Face to face
*Time/contact involved with non-coworkers/customers*															
*Using any number from 1 to 10, where 1 is little involvement or short routine involvements, and 10 means much of the work involves meeting or interacting for at least 10-15 minutes at a time with a customer, client, student or the public, what number would you use to rate this work?																	
gen contact1 =m5p16b
replace contact1 =0 if  m5p16 ==2
replace contact1=. if contact1==. |contact1<0 | contact1>10

gen contact_important = 1 if contact1 == 9 | contact1 ==10


*6. Direct and check the work of other workers (supervise)?												
gen contact2 =1 if  m5p18 ==1
replace contact2 =0 if  m5p18 ==2
replace contact2=. if contact2==. |contact2<0

* ICT use
* 7. Use telephone
gen  ict1=1 if  m5p20 ==1
replace  ict1=0 if  m5p20 ==2
replace ict1=. if ict1==. |ict1<0

* 8. Intensity of computer use										
gen  ict2= 1 if m5p24 ==4
replace  ict2= 2 if m5p24 ==3
replace  ict2= 3 if m5p24 ==2
replace  ict2= 4 if m5p24 ==1
replace  ict2=0 if  m5p23 ==2
replace ict2=. if ict2==. |ict2<0

*9. Not have internet at home
gen ict3=1 if m1b_q15_11==2 | m1b_q15_02==2
replace ict3=0 if m1b_q15_11==1 & m1b_q15_02==1
replace ict3=. if ict3==. |ict3<0

keep occupation occupationcode occ2 hh_size age earnings_h ln_earnings_h ict3 ict2 ict1 contact2 contact1 contact_important physical_manual5 physical_manual4 physical_manual3 physical_manual2 physical_manual1 age self_emp gender informal econ_sector occupation occupationcode country m1a_q09 W_FinSPwt_100 W_FinSPwt emptype_current emptype_previous
save "C:\Users\Jobs\COVID\STEP\STEPv_`x'",replace
 } 

 ****************************************************************************
*3. Appending Data*
****************************************************************************
clear 
use "C:\Users\Jobs\COVID\STEP\STEPv_BOL"

foreach x in COL LKA MKD ARM	SRB	LAO	GEO	GHA	KEN	VNM	PHL	UKR	SLV	XKX {
append using "C:\Users\Jobs\COVID\STEP\STEPv_`x'", force
}

save "C:\Users\Jobs\COVID\STEP\STEPv_covid.dta", replace


****************************************************************************
*4. Data Cleaning, Standardization, Construction of indexes*
****************************************************************************

*Keeping Workers in Employment Relationships or Self-Employed (NOT those in unpaid family work)*
clonevar emptype = emptype_current
replace emptype = emptype_previous if emptype == .
replace emptype = . if emptype < 0 | emptype == 97 
replace emptype = 9 if emptype == 4 | emptype == 5
drop if emptype == .
keep if emptype == 1 |emptype == 2

 
* Standardize each

foreach var in physical_manual1 physical_manual2 physical_manual3 physical_manual4 physical_manual5 contact1 contact2 ict1 ict2 ict3  {

sum `var' [w=W_FinSPwt_100]
gen `var'_std=(`var'-r(mean))/r(sd)

}

//Physically demanding and manual task index
egen physical_tot=rsum(physical_manual1_std physical_manual2_std physical_manual4_std physical_manual5_std) if physical_manual1_std!=. & physical_manual2_std!=. &physical_manual4_std!=. &physical_manual5_std!=. 

sum physical_tot  [w=W_FinSPwt_100]
gen physical_tot_std=(physical_tot-r(mean))/r(sd) 

//F2F task index
egen contact_tot =rsum(contact1_std contact2_std) if contact1_std!=. & contact2_std!=.
sum contact_tot  [w=W_FinSPwt_100]
gen contact_tot_std =(contact_tot -r(mean))/r(sd) 

//ICT task index (reverse)
gen low_ict1_std =-1*ict1_std
gen low_ict2_std =-1*ict2_std

egen ict_tot =rsum(low_ict1_std low_ict2_std) if low_ict1_std!=. & low_ict2_std!=.
sum ict_tot  [w=W_FinSPwt_100]
gen ict_tot_std =(ict_tot-r(mean))/r(sd) 

// ICT task index (reverse) with low ICT at home
egen ict_tot_ad =rsum(low_ict1_std low_ict2_std ict3_std) if low_ict1_std!=. & low_ict2_std!=. &ict3_std!=.
sum ict_tot_ad  [w=W_FinSPwt_100]
gen ict_tot_ad_std =(ict_tot_ad-r(mean))/r(sd) 

// Work from home index 
egen wfh_tot =rsum(physical_tot_std ict_tot_std contact_tot_std) if physical_tot_std!=.& ict_tot_std!=.& contact_tot_std!=.
sum wfh_tot  [w=W_FinSPwt_100]
gen wfh_tot_std =(wfh_tot-r(mean))/r(sd) 

// Work from home index with low ICT at home 
egen wfh_tot_ad =rsum(physical_tot_std ict_tot_std contact_tot_std ict3_std) if physical_tot_std!=.& ict_tot_std!=.& contact_tot_std!=.&ict3_std!=.
sum wfh_tot_ad  [w=W_FinSPwt_100]
gen wfh_tot_ad_std =(wfh_tot_ad-r(mean))/r(sd) 

// The share of jobs that can be done from home, following a methodology similar to Dingel & Neiman (2020a, 2020b). 
gen wfh_alt=0
replace wfh_alt=1 if ict2==0 | physical_manual1==1 |physical_manual4==1 |physical_manual5==1 |contact_important==1

sum wfh_alt [w=W_FinSPwt_100]
bysort country: egen total_wfh=total(wfh_alt)
bysort country: egen total=count(country)
g share_wfh_alt= total_wfh/total


* Age
 gen age_group =.
local count=1
forvalues i=16(10)64 {
replace age_group=`count' if age>=`i' & age<=`i'+9
local count=`count'+1
}

*Education
gen edulevel=.
replace edulevel=1 if m1a_q09==2 | m1a_q09==3| m1a_q09==4
replace edulevel=2 if m1a_q09==5
replace edulevel=3 if m1a_q09==6 | m1a_q09==7| m1a_q09==8

gen college=.
replace college=0 if edulevel==1|edulevel==2
replace college=1 if edulevel==3

replace occupation=. if occupation==0

save "C:\Users\Jobs\COVID\STEP\STEPv_covid_final.dta", replace

