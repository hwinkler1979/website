/********************************************************************

Project: Jobs' Amenability to Working from Home: Evidence from Skills 
Surveys for 53 countries

This do files: Prepares PIAAC database

*********************************************************************/

loc base_in_1 = "$path_wrk\bases\originales\prgmexp1.dta"
loc base_in_2 = "$path_wrk\bases\originales\prgecup1.dta"
loc base_in_3 = "$path_wrk\bases\originales\prgperp1.dta"
loc base_in_4 = "$path_wrk\bases\originales\prgautp1.dta"
loc base_in_5 = "$path_wrk\bases\originales\prgbelp1.dta"
loc base_in_6 = "$path_wrk\bases\originales\prgcanp1.dta"
loc base_in_7 = "$path_wrk\bases\originales\prgchlp1.dta"
loc base_in_8 = "$path_wrk\bases\originales\prgczep1.dta"
loc base_in_9 = "$path_wrk\bases\originales\prgdeup1.dta"
loc base_in_10 = "$path_wrk\bases\originales\prgdnkp1.dta"
loc base_in_11 = "$path_wrk\bases\originales\prgespp1.dta"
loc base_in_12 = "$path_wrk\bases\originales\prgestp1.dta"
loc base_in_13 = "$path_wrk\bases\originales\prgfinp1.dta"
loc base_in_14 = "$path_wrk\bases\originales\prgfrap1.dta"
loc base_in_15 = "$path_wrk\bases\originales\prggbrp1.dta"
loc base_in_16 = "$path_wrk\bases\originales\prggrcp1.dta"
loc base_in_17 = "$path_wrk\bases\originales\prghunp1.dta"
loc base_in_18 = "$path_wrk\bases\originales\prgirlp1.dta"
loc base_in_19 = "$path_wrk\bases\originales\prgisrp1.dta"
loc base_in_20 = "$path_wrk\bases\originales\prgitap1.dta"
loc base_in_21 = "$path_wrk\bases\originales\prgjpnp1.dta"
loc base_in_22 = "$path_wrk\bases\originales\prgkazp1.dta"
loc base_in_23 = "$path_wrk\bases\originales\prgkorp1.dta"
loc base_in_24 = "$path_wrk\bases\originales\prgltup1.dta"
loc base_in_25 = "$path_wrk\bases\originales\prgnldp1.dta"
loc base_in_26 = "$path_wrk\bases\originales\prgnorp1.dta"
loc base_in_27 = "$path_wrk\bases\originales\prgnzlp1.dta"
loc base_in_28 = "$path_wrk\bases\originales\prgpolp1.dta"
loc base_in_29 = "$path_wrk\bases\originales\prgrusp1.dta"
loc base_in_30 = "$path_wrk\bases\originales\prgsgpp1.dta"
loc base_in_31 = "$path_wrk\bases\originales\prgsvkp1.dta"
loc base_in_32 = "$path_wrk\bases\originales\prgsvnp1.dta"
loc base_in_33 = "$path_wrk\bases\originales\prgswep1.dta"
loc base_in_34 = "$path_wrk\bases\originales\prgturp1.dta"
loc base_in_35 = "$path_wrk\bases\originales\prgusap1_2012.dta"

loc base_out_1 = "$path_wrk\bases\mexico17.dta"
loc base_out_2 = "$path_wrk\bases\ecuador17.dta"
loc base_out_3 = "$path_wrk\bases\peru17.dta"
loc base_out_4 = "$path_wrk\bases\austria11_12.dta"
loc base_out_5 = "$path_wrk\bases\belgica11_12.dta"
loc base_out_6 = "$path_wrk\bases\canada11_12.dta"
loc base_out_7 = "$path_wrk\bases\chile14_15.dta"
loc base_out_8 = "$path_wrk\bases\czech_rep11_12.dta"
loc base_out_9 = "$path_wrk\bases\germany11_12.dta"
loc base_out_10 = "$path_wrk\bases\denmark11_12.dta"
loc base_out_11 = "$path_wrk\bases\spain11_12.dta"
loc base_out_12 = "$path_wrk\bases\estonia11_12.dta"
loc base_out_13 = "$path_wrk\bases\finland11_12.dta"
loc base_out_14 = "$path_wrk\bases\france11_12.dta"
loc base_out_15 = "$path_wrk\bases\uk11_12.dta"
loc base_out_16 = "$path_wrk\bases\greece14_15.dta"
loc base_out_17 = "$path_wrk\bases\hungary17.dta"
loc base_out_18 = "$path_wrk\bases\ireland11_12.dta"
loc base_out_19 = "$path_wrk\bases\israel14_15.dta"
loc base_out_20 = "$path_wrk\bases\italy11_12.dta"
loc base_out_21 = "$path_wrk\bases\japan11_12.dta"
loc base_out_22 = "$path_wrk\bases\kazakhstan17.dta"
loc base_out_23 = "$path_wrk\bases\korea11_12.dta"
loc base_out_24 = "$path_wrk\bases\lituania14_15.dta"
loc base_out_25 = "$path_wrk\bases\netherlands11_12.dta"
loc base_out_26 = "$path_wrk\bases\norway11_12.dta"
loc base_out_27 = "$path_wrk\bases\newzealand14_15.dta"
loc base_out_28 = "$path_wrk\bases\poland11_12.dta"
loc base_out_29 = "$path_wrk\bases\russia11_12.dta"
loc base_out_30 = "$path_wrk\bases\singapore14_15.dta"
loc base_out_31 = "$path_wrk\bases\slovakia11_12.dta"
loc base_out_32 = "$path_wrk\bases\slovenia14_15.dta"
loc base_out_33 = "$path_wrk\bases\sweden11_12.dta"
loc base_out_34 = "$path_wrk\bases\turkey14_15.dta"
loc base_out_35 = "$path_wrk\bases\usa12.dta"

loc base_out_all = "$path_wrk\bases\piaac_all.dta"

*********************************************************************

forvalues i=1/35 {

* Opens database
use "`base_in_`i''", clear

if `i'<=3 | `i'==5 | (`i'>=7 & `i'<=8) | (`i'>=10 & `i'<=12) | `i'==14 | `i'==16 | (`i'>=18 & `i'<=24) | `i'==26 | `i'==28 | `i'==31 | (`i'>=34 & `i'<=35) {
	loc variables "b_q01a b_q01a_t c_q01a c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==4 {
	loc variables "b_q01a_t c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a age_r h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==27 {
	loc variables "b_q01a b_q01a_t c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a age_r h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==6 | `i'==30 {
	loc variables "b_q01a b_q01a_t c_q01a c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a age_r h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==9 | `i'==17 {
	loc variables "c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a age_r h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==13 | `i'==32 {
	loc variables "c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==15 {
	loc variables "c_q01a c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==25 | `i'==29 {
	loc variables "b_q01a b_q01a_t c_q01a c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a gender_r h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==33 {
	loc variables "b_q01a b_q01a_t c_q01b c_q01c d_q04 d_q03 d_q06a d_q09 d_q10 h_q05a h_q05h d_q08a d_q07a d_q08b d_q11a d_q11b d_q11c d_q11d d_q13a d_q13b d_q13c f_q01b f_q02a f_q02b f_q02c f_q02d f_q02e f_q03a f_q03b f_q03c f_q04a f_q04b f_q05a f_q05b f_q06b f_q06c g_q01a g_q01b g_q01c g_q01d g_q01e g_q01f g_q01g g_q01h g_q02a g_q02b g_q02c g_q02d g_q03b g_q03c g_q03d g_q03f g_q03g g_q03h g_q04 g_q05a g_q05c g_q05d g_q05e g_q05f g_q05g g_q05h h_q04b h_q04a h_q05c h_q05d h_q05e h_q05f h_q05g"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}
if `i'==35 {
	loc variables "age_r"
	foreach var of local variables {
		ren `var' `var'_aux
		gen `var'=real(`var'_aux)
		}
	drop *_aux
	}

* Individual weights
gen weight=spfwt0

* Gender
gen female=1 if gender_r==2
replace female=0 if gender_r==1
label var female "=1 if female"

* Age
gen age=age_r

* Age groups
gen age_group=1 if age>=15 & age<=24
replace age_group=2 if age>=25 & age<=34 
replace age_group=3 if age>=35 & age<=44 
replace age_group=4 if age>=45 & age<=54 
replace age_group=5 if age>=55 & age<65
label var age_group "Age groups"
label define age_group 1 "15-24" 2 "25-34" 3 "35-44" 4 "45-54" 5 "55-65"
label values age_group age_group

* Educational level
/* b_q01a_t: Highest level of schooling (Trend-IALS/ALL)
	1=Less than high school 
	2=High school 
	3=Above high school
	4=Not definable */    
gen educ_level=1 if b_q01a_t==1
replace educ_level=2 if b_q01a_t==2
replace educ_level=3 if b_q01a_t==3
replace educ_level=. if b_q01a_t==4
label var educ_level "Educational level"
label define educ_level 1 "Less than high school" 2 "High school" 3 "Above high school" 
label values educ_level educ_level

/* b_q01a: Which of the qualifications on this card is the highest you have obtained? If the respondent is currently enrolled in an educational programme, emphasize that the question refers to education that has been completed, and that current education will be addressed in a later question
	01=No formal qualification or below ISCED 1
	02=ISCED 1 - Primary
	03=ISCED 2 - Lower secondary education
	04=ISCED 3C shorter than 2 years - Upper secondary education
	05=ISCED 3C 2 years or more - Upper secondary education
	06=ISCED 3A-B - Upper secondary education
	07=ISCED 3 (without distinction A-B-C, 2y+) - Upper secondary education
	08=ISCED 4C - Post-secondary, non-tertiary education
	09=ISCED 4A-B - Post-secondary, non-tertiary education
	10=ISCED 4 (without distinction A-B-C) - Post-secondary, non-tertiary education
	11=ISCED 5B - First stage of tertiary education
	12=ISCED 5A, bachelor degree - First stage of tertiary education
	13=ISCED 5A, master degree - First stage of tertiary education
	14=ISCED 6 - Bachelor or equivalent - Second stage of tertiary education
	15=Foreign qualification */
gen educ_survey=b_q01a
label var educ_survey "Educational level - Original variable"

* Dummy of above high school education
if `i'!=4 {
	gen high_educ=1 if educ_level==3
	replace high_educ=0 if educ_level==1 | educ_level==2
	label var high_educ "=1 if above high school"
	}
if `i'==4 {
	gen high_educ=1 if educ_survey>=11 & educ_survey<=14
	replace high_educ=0 if educ_survey<=10 | educ_survey==15
	label var high_educ "=1 if above high school"
	}

* Employment
/* C_Q01a: In the last week, did you do any PAID work for at least one hour, either as an employee or as self-employed? 
   C_Q01b: Last week, were you away from a job or business that you plan to return to? 
   C_Q01c: Last week, did you do any UNPAID work for at least one hour for a business that you own or a relative owns? */
gen employed=1 if c_q01a==1
replace employed=0 if c_q01a==2
replace employed=1 if c_q01a==2 & c_q01b==1
replace employed=1 if c_q01a==2 & c_q01c==1
label var employed "=1 if employed"

* Employment category
/* D_Q04: In this job, are you working as an employee or are you selfemployed? 
	1=Employee - By employee we mean someone who gets a salary or wage from an employer or a temporary employment agency - Unpaid workers are excluded
	2=Self-employed - A self-employed person may or may not have personnel */
gen empl_cat=d_q04
replace empl_cat=3 if empl_cat==2
label var empl_cat "Employment category"
label define empl_cat 1 "Wage employee" 2 "Employer" 3 "Self-employed" 4 "Unpaid family worker"
label values empl_cat empl_cat

gen wage_employee=1 if empl_cat==1
replace wage_employee=0 if empl_cat!=1 & empl_cat!=.
label var wage_employee "=1 if wage employee"

* Occupation (1 digit)
/* isco08_c: Current Job Occupation - Respondent (ISCO 2008)*/
gen occup=isco1c
replace occup=. if occup==0 | occup>9
label var occup "Occupation at 1 digit"

gen occup_decomp=isco08_c

* Economic sector
/* Current Job Industry - Respondent (ISIC rev 4)
	A=Agriculture, forestry and fishing 
	B=Mining and quarrying 
	C=Manufacturing 
	D=Electricity, gas, steam and air conditioning supply 
	E=Water supply; sewerage, waste management and remediation activities 
	F=Construction 
	G=Wholesale and retail trade; repair of motor vehicles and motorcycles 
	H=Transportation and storage 
	I=Accommodation and food service activities 
	J=Information and communication 
	K=Financial and insurance activities 
	L=Real estate activities 
	M=Professional, scientific and technical activities 
	N=Administrative and support service activities 
	O=Public administration and defence; compulsory social security 
	P=Education 
	Q=Human health and social work activities 
	R=Arts, entertainment and recreation 
	S=Other service activities 
	T=Activities of households as employers; undifferentiated goods- and services-producing activities of households for own use 
	U=Activities of extraterritorial organizations and bodies */
replace isic1c="" if isic1c=="9995" | isic1c=="9996" | isic1c=="9997" | isic1c=="9998" | isic1c=="9999" 
gen sector=.
replace sector=1 if isic1c=="A"
replace sector=2 if isic1c=="B"
replace sector=3 if isic1c=="C"
replace sector=4 if isic1c=="D"
replace sector=5 if isic1c=="E"
replace sector=6 if isic1c=="F"
replace sector=7 if isic1c=="G"
replace sector=8 if isic1c=="H"
replace sector=9 if isic1c=="I"
replace sector=10 if isic1c=="J"
replace sector=11 if isic1c=="K"
replace sector=12 if isic1c=="L"
replace sector=13 if isic1c=="M"
replace sector=14 if isic1c=="N"
replace sector=15 if isic1c=="O"
replace sector=16 if isic1c=="P"
replace sector=17 if isic1c=="Q"
replace sector=18 if isic1c=="R"
replace sector=19 if isic1c=="S"
replace sector=20 if isic1c=="T"
replace sector=. if isic1c=="U"
label var sector "Economic sector 1 digit"

* Formality
/* d_q09: What kind of employment contract do you have?
	1=An indefinite contract
	2=A fixed term contract
	3=A temporary employment agency contract
	4=An apprenticeship or other training scheme
	5=No contract
	6=Other */
gen formal=1 if d_q09==1 | d_q09==2 | d_q09==3 | d_q09==4 | d_q09==6 
replace formal=0 if d_q09==5
label var formal "Has a labor contract"

* ICT at home
* Questions are about the use of internet in everyday life; this could be at home or in other places that offer internet services, like internet cafes or libraries; we assume it is at home, meaning the person has access to internet at home 
/* H_Q04a: Have you ever use a computer? (This includes cell-phones and other hand-held electronic devices that are used to connect to the internet, check e-mails etc.)
   H_Q04b: Do you use a computer in your everyday life now ^OutsideWork? (This includes cell-phones and other hand-held electronic devices that are used to connect to the internet, check e-mails etc.)
   H_Q05a: In every day life, how often do you usually use email?
   H_Q05c: Use the internet in order to better understand issues related to, for example, your health or illnesses, financial matters, or environmental issues?
   H_Q05d: Conduct transactions on the internet, for example buying or selling products or services, or banking?
   H_Q05e: Use spreadsheet software, for example Excel?
   H_Q05f: Use a word processor, for example Word?
   H_Q05g: Use a programming language to program or write computer code?
   H_Q05h: In every day life, how often do you participate in real-time discussions on the internet, for example online conferences or chat groups?
	1=Never
	2=Less than once a month
	3=Less than once a week but at least once a month
	4=At least once a week but not every day
	5=Every day */

* Indicator variables 
loc variables "a c d e f g h"
foreach v of local variables {
	gen internet_indiv_`v'=1 if h_q05`v'>=2 & h_q05`v'<=5
	replace internet_indiv_`v'=0 if h_q05`v'==1 
	replace internet_indiv_`v'=0 if h_q04b==2 | h_q04a==2
	}

* Indicator of at least one activity
gen internet_indiv=1 if internet_indiv_a==1 | internet_indiv_c==1 | internet_indiv_d==1 | internet_indiv_e==1 | internet_indiv_f==1 | internet_indiv_g==1 | internet_indiv_h==1
replace internet_indiv=0 if internet_indiv_a==0 & internet_indiv_c==0 & internet_indiv_d==0 & internet_indiv_e==0 & internet_indiv_f==0 & internet_indiv_g==0 & internet_indiv_h==0

*	Reverse order
gen nointernet_indiv=1 if internet_indiv==0
replace nointernet_indiv=0 if internet_indiv==1

* Sample 
if `i'<=3 | `i'==5 | (`i'>=7 & `i'<=8) | (`i'>=10 & `i'<=13) | (`i'>=14 & `i'<=16) | (`i'>=18 & `i'<=26) | (`i'>=28 & `i'<=29) | (`i'>=31 & `i'<=34) {
	gen sample=1 if age>=16 & age<=64 & employed==1 & educ_level!=. & female!=. 
	replace sample=. if occup==. | sector==. 
	}
if `i'==6  | `i'==9  | `i'==17 | `i'==27 | `i'==30 | `i'==35 {
	gen sample=1 if employed==1 & educ_level!=. & female!=.
	replace sample=. if occup==. | sector==. 
	}
if `i'==4 {
	gen sample=1 if employed==1 & educ_survey!=. & female!=.
	replace sample=. if occup==. | sector==. 
	}
* AUT, CAN, GER, HUN, NZE, SGP, USA don't have information on age 
keep if sample==1

* Physically effort and manual skills variables 
/* F_Q06b: How often does your job usually involve working physically for a long period?
   F_Q06c: How often does your job usually involve using skill or accuracy with your hands or fingers?
	1=Never
	2=Less than once a month
	3=Less than once a week but at least once a month
	4=At least once a week but not every day
	5=Every day */
gen physical=f_q06b
label var physical "Working physically for a long period"

gen manual=f_q06b
label var manual "Using skills or accuracy with hands or fingers"

* ICT variables
/* G_Q04: Do you use a computer in your job?
   G_Q05a: In your job, how often do you usually use email?
   G_Q05c: In your job, how often do you usually use the internet in order to better understand issues related to your work?
   G_Q05d: In your job, how often do you usually conduct transactions on the internet, for example buying or selling products or services, or banking?
   G_Q05e: In your job, how often do you usually use spreadsheet software, for example Excel?
   G_Q05f: In your job, how often do you usually use a word processor, for example Word?
   G_Q05g: In your job, how often do you usually use a programming language to program or write computer code?
   G_Q05h: In your job, how often do you usually participate in real-time discussions on the internet, for example online conferences, or chat groups?
	1=Never
	2=Less than once a month
	3=Less than once a week but at least once a month
	4=At least once a week but not every day
	5=Every day */
gen computer=1 if g_q04==1
replace computer=0 if g_q04==2
label var computer "Use of computer"

gen email=g_q05a
gen internet=g_q05c
gen ebusiness=g_q05d
gen excel=g_q05e
gen word=g_q05f
gen programming=g_q05g
gen onlineconference=g_q05h

replace email=1 if computer==0
replace internet=1 if computer==0
replace ebusiness=1 if computer==0
replace excel=1 if computer==0
replace word=1 if computer==0
replace programming=1 if computer==0
replace onlineconference=1 if computer==0

label var email "Use email"
label var internet "Use the internet"
label var ebusiness "Conduct transactions on the internet"
label var excel "Use spreadsheet software"
label var word "Use word processor"
label var programming "Use programming language"
label var onlineconference "Participate in real-time discussions"

*	Reverse order
gen nocomputer=1 if computer==0
replace nocomputer=0 if computer==1

loc variables "email internet ebusiness excel word programming onlineconference"
foreach var of local variables {
	gen no`var'=.
	replace no`var'=1 if `var'==5
	replace no`var'=2 if `var'==4
	replace no`var'=3 if `var'==3
	replace no`var'=4 if `var'==2
	replace no`var'=5 if `var'==1
	}

* Social interaction variables
/* D_Q07a: Do you have employees working for you? Please include family members working paid or unpaid in the business
   D_Q08a: Do you manage or supervise other employees? --> ONLY FOR PERSONS WHO EMPLOY OTHER PEOPLE; DOESN'T INCLUDE MANAGMENET/SUPERVISION OF MANAGEMENT POSITIONS
   F_Q01b: In your job what proportion of your time do you usually spend cooperating or collaborating with co-workers?
	1=None of the time
	2=Up to a quarter of the time
	3=Up to half of the time
	4=More than half of the time
	5=All the time
   F_Q02a: How often does your job usually involve sharing work-related information with co-workers?
   F_Q02b: How often does your job usually involve instructing, training or teaching people, individually or in groups?
   F_Q02c: How often does your job usually involve making speeches or giving presentations in front of five or more people?
   F_Q02d: How often does your job usually involve selling a product or selling a service?
   F_Q02e: How often does your job usually involve advising people?
	1=Never
	2=Less than once a month
	3=Less than once a week but at least once a month
	4=At least once a week but not every day
	5=Every day 
   F_Q04a: How often does your job usually involve persuading or influencing people?
   F_Q04b: How often does your job usually involve negotiating with people either inside or outside your firm or organisation?
	1=Never
	2=Less than once a month
	3=Less than once a week but at least once a month
	4=At least once a week but not every day
	5=Every day */
gen supervise=1 if d_q08a==1
replace supervise=0 if d_q08a==2 | d_q07a==2
label var supervise "Supervise other employees"

gen cooperation=f_q01b
label var cooperation "Time cooperating/collaborating with co-workers"

gen sharing=f_q02a
gen teaching=f_q02b
gen presenting=f_q02c
gen selling=f_q02d
gen advising=f_q02e
label var sharing "Sharing work-related information with co-workers"
label var teaching "Instructing/training/teaching"
label var presenting "Making speeches/giving presentations"
label var selling "Selling products/services"
label var advising "Advising people"

gen persuading=f_q04a 
gen negotiating=f_q04b 
label var persuading "Persuading/influencing people"
label var negotiating "Negotiating"

* Corrects sample
replace sample=. if physical==. | manual==. | computer==. | email==. | internet==. | ebusiness==. | excel==. | word==. | programming==. | onlineconference==. | sharing==. | teaching==. | presenting==. | selling==. | advising==. | persuading==. | negotiating==. | nointernet_indiv==.
keep if sample==1
*cooperating --> Has several missing values in most countries
*supervise --> Only available for self-employed workers

* Adjusts weight so each country has equal weight
ren weight weight_piaac
sum weight_piaac 
loc sum=r(sum)
gen weight=weight_piaac/`sum'
sum weight

* Country codes
gen country=`i'
gen country_code=""
if `i'==1 {
	replace country_code="MEX"
	}
if `i'==2 {
	replace country_code="ECU"
	}
if `i'==3 {
	replace country_code="PER"
	}
if `i'==4 {
	replace country_code="AUT"
	}
if `i'==5 {
	replace country_code="BEL"
	}
if `i'==6 {
	replace country_code="CAN"
	}
if `i'==7 {
	replace country_code="CHL"
	}
if `i'==8 {
	replace country_code="CZE"
	}
if `i'==9 {
	replace country_code="DEU"
	}
if `i'==10 {
	replace country_code="DNK"
	}
if `i'==11 {
	replace country_code="ESP"
	}
if `i'==12 {
	replace country_code="EST"
	}
if `i'==13 {
	replace country_code="FIN"
	}
if `i'==14 {
	replace country_code="FRA"
	}
if `i'==15 {
	replace country_code="GBR"
	}
if `i'==16 {
	replace country_code="GRC"
	}
if `i'==17 {
	replace country_code="HUN"
	}
if `i'==18 {
	replace country_code="IRL"
	}
if `i'==19 {
	replace country_code="ISR"
	}
if `i'==20 {
	replace country_code="ITA"
	}
if `i'==21 {
	replace country_code="JPN"
	}
if `i'==22 {
	replace country_code="KAZ"
	}
if `i'==23 {
	replace country_code="KOR"
	}
if `i'==24 {
	replace country_code="LTU"
	}
if `i'==25 {
	replace country_code="NLD"
	}
if `i'==26 {
	replace country_code="NOR"
	}
if `i'==27 {
	replace country_code="NZL"
	}
if `i'==28 {
	replace country_code="POL"
	}
if `i'==29 {
	replace country_code="RUS"
	}
if `i'==30 {
	replace country_code="SGP"
	}
if `i'==31 {
	replace country_code="SVK"
	}
if `i'==32 {
	replace country_code="SVN"
	}
if `i'==33 {
	replace country_code="SWE"
	}
if `i'==34 {
	replace country_code="TUR"
	}
if `i'==35 {
	replace country_code="USA"
	}

* Saves 
keep country_code country weight weight_piaac age age_group female occup sector empl_cat educ_lev educ_survey formal internet_indiv* nointernet_indiv physical manual nocomputer noemail nointernet noebusiness noexcel noword noprogramming noonlineconference sharing teaching presenting selling advising persuading negotiating high_educ wage_employee occup_decomp 
save "`base_out_`i''", replace
}

*********************************************************************

* Append 
use "`base_out_1'", clear
forvalues i=2/35 {
	append using "`base_out_`i''", force
	}

* (A) Standardization method
loc variables "physical manual nocomputer noemail nointernet noebusiness noexcel noword noprogramming noonlineconference sharing teaching presenting selling advising persuading negotiating nointernet_indiv"
foreach var of local variables {
	sum `var' [w=weight] 
	loc mean=r(mean)
	loc sd=r(sd)
	gen `var'_st=(`var'-`mean')/`sd'
	}

* (1) Physically demanding and manual task index
egen physical_manual_aux=rowtotal(physical_st manual_st)
sum physical_manual_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen physical_manual=(physical_manual_aux-`mean')/`sd'
drop *_aux
label var physical_manual "Physically demanding and manual task index"

* (2) ICT task index (reverse)
egen ict_aux=rowtotal(nocomputer_st noemail_st nointernet_st noebusiness_st noexcel_st noword_st noprogramming_st noonlineconference_st)
sum ict_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen ict=(ict_aux-`mean')/`sd'
label var ict "ICT task index"

* (3) F2F task index
egen f2f_aux=rowtotal(teaching_st presenting_st selling_st advising_st persuading_st negotiating_st)
*sharing_st 
sum f2f_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen f2f=(f2f_aux-`mean')/`sd'
drop *_aux
label var f2f "In-person face-to-face task index"
* NOTE: Sharing has a high frequency for most workers

* (6) Work from home
* Restricts to variables closer to Dingel & Neiman (2020)

*	Standardized version
egen nowfh_aux=rowtotal(physical_manual ict f2f)
sum nowfh_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen nowfh=(nowfh_aux-`mean')/`sd'
drop *_aux
label var nowfh "Reverse work from home index"

egen nowfh_v2_aux=rowtotal(physical_manual ict f2f nointernet_indiv_st)
sum nowfh_v2_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen nowfh_v2=(nowfh_v2_aux-`mean')/`sd'
drop *_aux
label var nowfh_v2 "Reverse work from home index - Correcting for internet access"

*	Binary version
/* 	1=Never
	2=Less than once a month
	3=Less than once a week but at least once a month
	4=At least once a week but not every day
	5=Every day */
gen id_nowfh=0 if physical!=. & noemail!=. & selling!=. 
replace id_nowfh=1 if (physical>=4 & physical<=5) | (noemail>=4 & noemail<=5) | (selling>=4 & selling<=5) 
label var id_nowfh "Reverse work from home index - Binary version"

gen id_nowfh_v2=0 if physical!=. & noemail!=. & selling!=. & nointernet_indiv!=.
replace id_nowfh_v2=1 if (physical>=4 & physical<=5) | (noemail>=4 & noemail<=5) | (selling>=4 & selling<=5) | nointernet_indiv==1
label var id_nowfh_v2 "Reverse work from home index - Binary version - Correcting for internet access"

* Check standardization
sum physical_manual ict f2f nowfh nowfh_v2 id_nowfh id_nowfh_v2 [w=weight] 

* Saves 
save "`base_out_all'", replace


