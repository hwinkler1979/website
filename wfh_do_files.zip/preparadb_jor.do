/********************************************************************

Project: Jobs' Amenability to Working from Home: Evidence from Skills 
Surveys for 53 countries

This do files: Prepares Jordan database

*********************************************************************/

loc base_in = "$path_wrk\bases\originales\JLMPS 2016 xs v1.1.dta"
loc base_out = "$path_wrk\bases\jordan16.dta"

*********************************************************************

* Opens database
use "`base_in'", clear

* Individual weights
gen weight=round(expan_indiv)

* Gender
gen female=1 if sex==2
replace female=0 if sex==1
label var female "=1 if female"

* Age 
* age

* Age groups
gen age_group=1 if age>=15 & age<=24
replace age_group=2 if age>=25 & age<=34 
replace age_group=3 if age>=35 & age<=44 
replace age_group=4 if age>=45 & age<=54 
replace age_group=5 if age>=55 & age<65
label var age_group "Age groups"
label define age_group 1 "15-24" 2 "25-34" 3 "35-44" 3 "45-54" 3 "55-65"
label values age_group age_group

* Dummy of above high school education
/* educ1d: Educational level (1 digit) */
gen high_educ=0 if educ1d<=5
replace high_educ=1 if educ1d==6 | educ1d==7
label var high_educ "=1 if above high school"

* Employment
/* crwrkstsr2: Work status during ref. week, extend. def. (search required) */
gen employed=1 if crwrkstsr2==1
replace employed=0 if crwrkstsr2==2 | crwrkstsr2==3
label var employed "=1 if employed"

* Employment category
/* crempstp: Employment status in prim job (ref. 1-week)
	1=Wage employee
	2=Employer
	3=Self-employed
	4=Unpaid family workers */
gen empl_cat=crempstp
label var empl_cat "Employment category"
label define empl_cat 1 "Wage employee" 2 "Employer" 3 "Self-employed" 4 "Unpaid family worker"
label values empl_cat empl_cat

gen wage_employee=1 if empl_cat==1
replace wage_employee=0 if empl_cat!=1 & empl_cat!=.
label var wage_employee "=1 if wage employee"

* Occupation (1 digit)
/* crocp1d: Occup. of prim. job (1-digit ref. 1-week)
	1=Managers
	2=Professionals
	3=Technicians and associate professionals
	4=Clerical support workers
	5=Service and sales workers
	6=Skilled agricultural, forestry and fish
	7=Craft and related trades workers
	8=Plant and machine operators, and assemb
	9=Elementary occupations */
ren crocp1d occup
label var occup "Occupation at 1 digit"

* Economic sector
/* crecac1d: Economic activity of prim. job (1-digit) (ref. 1-week)
	0=Agriculture, forestry and fishing	
	1=Mining and quarrying	
	2=Manufacturing	
	3=Electricity,gas,steam and air conditi	
	4=Water supply;sewage,waste management	
	5=Construction	
	6=Wholesale and retail trade; repair of	
	7=Transportation and storage	
	8=Accomodation and food service activit	
	9=Information and communication	
	10=Financial and insurance activities	
	11=Real estate activities	
	12=Professional, scientific and technica	
	13=Administrative and support service ac	
	14=Public administration and defense; co	
	15=Education	
	16=Human health and social work activiti	
	17=Arts, entertainment and recreation	
	18=other service activities	
	19=Activities of households as employers 
	20=Activities of extraterritorial organizations */
ren crecac1d sector
label var sector "Economic sector 1 digit"

* Formality
/* crformal: Formality of prim. job (ref. 1-Week) 
   q6132: Do you have social insurance connected to this job? */
gen formal_survey=crformal
gen formal=1 if q6132==1
replace formal=0 if q6132==2
label var formal_survey "Formality of primary job - Defined as in survey"
label var formal "Has social insurance at work"

* Place of work
/* q6170: Describe your place of work
   1=Own home */
gen place_work=q6170
gen place_work_home=1 if q6170==1
replace place_work_home=0 if q6170!=1 & q6170!=98 & q6170!=.

*	Reverse order
gen noplace_work_home=1 if place_work_home==0
replace noplace_work_home=0 if place_work_home==1

* ICT at home
ren mobile mobile_survey
gen mobile_home=mobile_survey
label var mobile_home "Own a mobile phone - Hhld level"

gen comp_home=PC
label var comp_home "Own a computer - Hhld level"

ren internet internet_survey
gen internet_home=internet_survey
label var internet_home "Internet connection - Hhld level"

/* q12002: Do you own a mobile phone?
   q12005: Do you use the internet on your phone?
	1=Yes, through an internet data plan 
	2=Yes, through WiFi
	3=Yes, both
	4=No */
gen mobile_indiv=1 if q12002==1
replace mobile_indiv=0 if q12002==2
label var mobile_indiv "Own a mobile phone - Individual level"

gen internet_indiv=1 if (q12005>=1 & q12005<=3) | internet_home==1
replace internet_indiv=0 if q12005==4 & internet_home==0
label var internet_indiv "Access to internet - Individual level"

*	Reverse order
gen nointernet_indiv=1 if internet_indiv==0
replace nointernet_indiv=0 if internet_indiv==1

* Sample 
gen sample=1 if age>=16 & age<=64 & employed==1 
replace sample=. if occup==. | sector==. | educ_level==. | female==.
keep if sample==1

*********************************************************************

* Physically effort and manual skills variables 
/* q6116_3: Does your job require physical fitness?
   q6107: Does your job require any technical skills?
   q6109: Is the individual engaged in a craft-related job? (If q6107==1)
   q6167: Do you carry heavy stuff at your work? - N/A in Jordan
   q6168: Do you operate any heavy machines at your work? - N/A in Jordan */
gen physical_skills=1 if q6116_3==1
replace physical_skills=0 if q6116_3==2
label var physical_skills "Job require physical fitness"

gen manual=1 if q6109==1
replace manual=0 if q6109==2 | q6107==2
label var manual "Craft-related job"

gen carry_heavy=1 if q6167==1
replace carry_heavy=0 if q6167==2 
label var carry_heavy "Carry heavy stuff at work"

gen machine=1 if q6168==1
replace machine=0 if q6168==2 
label var machine "Operate heavy machines at work"

* Work context - N/A in Jordan
/* q6169_1: Are you exposed to dust and flames
   q6169_2: Are you exposed to fire or fuel
   q6169_3: Are you exposed to loud noise and vibrations
   q6169_4: Are you exposed to extreme high heat/ extreme low heat
   q6169_5: Are you exposed to high risk equipment
   q6169_6: Are you exposed to work underground
   q6169_7: Are you exposed to working in sea/river
   q6169_8: Are you exposed to working in a dark place
   q6169_9: Are you exposed to insufficient ventilation/ smelly place
   q6169_10: Are you exposed to chemicals/ pesticides
   q6169_11: Are you exposed to explosives (firecrackers) 
   q6169_12: Are you exposed to bending for a long time
   q6169_13: Are you exposed to no toilet
   q6169_14: Other things against the security and safety measures (specify) */
gen dust=1 if q6169_01==1
replace dust=0 if q6169_01==2 
label var dust "Exposed to dust and flames"

gen fire=1 if q6169_02==1
replace fire=0 if q6169_02==2 
label var fire "Exposed to fire or fuel"

gen noise=1 if q6169_03==1
replace noise=0 if q6169_03==2 
label var noise "Exposed to loud noise and vibrations"

gen heat=1 if q6169_04==1
replace heat=0 if q6169_04==2 
label var heat "Exposed to extreme high heat/extreme low heat"

gen risk=1 if q6169_05==1
replace risk=0 if q6169_05==2 
label var risk "Exposed to high risk equipment"

gen underground=1 if q6169_06==1
replace underground=0 if q6169_06==2 
label var underground "Exposed to work underground"

gen sea_river=1 if q6169_07==1
replace sea_river=0 if q6169_07==2 
label var sea_river "Exposed to working in sea/river"

gen dark=1 if q6169_08==1
replace dark=0 if q6169_08==2 
label var dark "Exposed to working in a dark place"

gen nonvent=1 if q6169_09==1
replace nonvent=0 if q6169_09==2 
label var nonvent "Exposed to insufficient ventilation/smelly place"

gen chemical=1 if q6169_10==1
replace chemical=0 if q6169_10==2 
label var chemical "Exposed to chemicals/pesticides"

gen explosives=1 if q6169_11==1
replace explosives=0 if q6169_11==2 
label var explosives "Exposed to explosives (firecrackers)" 

gen bending=1 if q6169_12==1
replace bending=0 if q6169_12==2 
label var bending "Exposed to bending for a long time"

* ICT variables
/* q6116_4: Does your job require computer skills? 
   q6117: Do you use a computer in your work? And if so is this computer connected to the internet? 
	1=Yes, connected to the internet
	2=Yes, not connected to the internet
	3=No */
gen comp_skills=1 if q6116_4==1
replace comp_skills=0 if q6116_4==2

gen use_comp=1 if q6117==1 | q6117==2
replace use_comp=0 if q6117==3

gen internet=1 if q6117==1
replace internet=0 if q6117==2 | q6117==3

*	Reverse order
gen nocomp_skills=1 if comp_skills==0
replace nocomp_skills=0 if comp_skills==1

gen nouse_comp=1 if use_comp==0
replace nouse_comp=0 if use_comp==1

gen nointernet=1 if internet==0
replace nointernet=0 if internet==1

* Social interaction variables
/* q6116_5: Does your job require management skills - N/A in Jordan
   q6116_6: Does your job require customer service skills - N/A in Jordan
   q6105: Does your job require supervising others? 
	1=Yes
	2=No 
   q6106: How many people do you supervise?
        98=Don't know
	99=More than 100 
   q6132: Do you deal with the general public in your job? - N/A in Jordan */ 
gen supervise=1 if q6105==1
replace supervise=0 if q6105==2
label var supervise "Job requires supervising others"

* Corrects sample
replace sample=. if physical_skills==. | manual==. | nouse_comp==. | nointernet==. | supervise==. | nointernet_indiv==. 
keep if sample==1

* Adjusts weight so each country has equal weight
ren weight weight_survey
sum weight_survey
loc sum=r(sum)
gen weight=weight_survey/`sum'
sum weight

* Saves 
capture drop country
gen country=2 
gen country_code="JOR"
keep country_code country weight weight_survey age age_group female occup sector empl_cat formal place_work_home noplace_work_home physical_skills manual use_comp internet nouse_comp nointernet supervise internet_indiv nointernet_indiv high_educ wage_employee
save "`base_out'", replace
