/********************************************************************

Project: Jobs' Amenability to Working from Home: Evidence from Skills 
Surveys for 53 countries

This do files: Prepares MENA database

*********************************************************************/

loc base_in_1 = "$path_wrk\bases\egypt18.dta"
loc base_in_2 = "$path_wrk\bases\jordan16.dta"
loc base_in_3 = "$path_wrk\bases\tunisia14.dta"

loc base_out_all = "$path_wrk\bases\mena_all.dta"

*********************************************************************

* Append 
use "`base_in_1'", clear
forvalues i=2/3 {
	append using "`base_in_`i''", force
	}

* (A) Standardization method

*	Variable savailable in all countries
loc variables "physical_skills manual supervise nouse_comp nointernet nointernet_indiv noplace_work_home"
foreach var of local variables {
	sum `var' [w=weight] 
	loc mean=r(mean)
	loc sd=r(sd)
	gen `var'_st=(`var'-`mean')/`sd'
	}

*	Variable savailable in EGY only
loc variables "dust fire noise heat risk underground sea_river dark nonvent chemical explosives"
foreach var of local variables {
	sum `var' [w=weight] if country==1
	loc mean=r(mean)
	loc sd=r(sd)
	gen `var'_st=(`var'-`mean')/`sd' if country==1
	}

* (1) Physically demanding and manual task index
egen physical_manual_aux=rowtotal(physical_skills_st manual_st)
sum physical_manual_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen physical_manual=(physical_manual_aux-`mean')/`sd'
drop *_aux
label var physical_manual "Physically demanding and manual task index"

* (2) ICT task index (reverse)
egen ict_aux=rowtotal(nouse_comp_st nointernet_st)
sum ict_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen ict=(ict_aux-`mean')/`sd'
drop *_aux
label var ict "ICT task index"

* (3) F2F task index
egen f2f_aux=rowtotal(supervise_st)
sum f2f_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen f2f=(f2f_aux-`mean')/`sd'
drop *_aux
label var f2f "In-person face-to-face task index"

* (5) Context
egen context_aux=rowtotal(dust_st fire_st heat_st risk_st underground_st sea_river_st dark_st chemical_st explosives_st) if country==1
sum context_aux [w=weight] if country==1
loc mean=r(mean)
loc sd=r(sd)
gen context=(context_aux-`mean')/`sd' if country==1
drop *_aux
label var context "Job context not favorable for working from home"

* (6) Work from home
* Restricts to variables closer to Dingel & Neiman (2020)
egen nowfh_aux=rowtotal(physical_manual ict f2f noplace_work_home_st)
sum nowfh_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen nowfh=(nowfh_aux-`mean')/`sd'
drop *_aux
label var nowfh "Reverse work from home index"

egen nowfh_v2_aux=rowtotal(physical_manual ict f2f noplace_work_home_st nointernet_indiv_st)
sum nowfh_v2_aux [w=weight] 
loc mean=r(mean)
loc sd=r(sd)
gen nowfh_v2=(nowfh_v2_aux-`mean')/`sd'
drop *_aux
label var nowfh_v2 "Reverse work from home index - Correcting for internet access"

* Check standardization
sum physical_manual ict f2f context nowfh nowfh_v2 [w=weight] 

* Saves 
save "`base_out_all'", replace
