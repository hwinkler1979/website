==============================================================================================
Project:			Measuring Green Jobs: A New Database for Latin America and other Regions

Authors:			Kelly Y. Montoya, Emmanuel J. Vazquez, & Hernan J. Winkler
e-mails:			kmontoyamunoz@worldbank.org, evazquez@cedlas.org, hwinkler@worldbank.org
Institution:		World Bank Group - ELCPV

Date:				19/03/2024
Last update: 		05/02/2024
================================================================================================

** INTERMEDIATE OUTPUTS **
** README FILE **

"ilo_proccessed_with_lac": proportion of green occupations by country and year (GLOBAL)
"green_occ_isco08_Xd.csv": proportion of green occupations by ISCO08 category at the X-digit level
"emissions_per_worker.csv": GHGE per worker for selected LAC countries, by year and sector