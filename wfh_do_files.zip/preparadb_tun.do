/********************************************************************

Project: Jobs' Amenability to Working from Home: Evidence from Skills 
Surveys for 53 countries

This do files: Prepares Tunisia database

*********************************************************************/

loc base_in = "$path_wrk\bases\originales\TLMPS 2014 v2.0 all.dta"
loc base_out = "$path_wrk\bases\tunisia14.dta"

*********************************************************************

* Opens database
use "`base_in'", clear

* Individual weights
gen weight=round(expan_indiv)

* Gender
gen female=1 if sex==2
replace female=0 if sex==1
label var female "=1 if female"

* Age 
* age

* Age groups
gen age_group=1 if age>=15 & age<=24
replace age_group=2 if age>=25 & age<=34 
replace age_group=3 if age>=35 & age<=44 
replace age_group=4 if age>=45 & age<=54 
replace age_group=5 if age>=55 & age<65
label var age_group "Age groups"
label define age_group 1 "15-24" 2 "25-34" 3 "35-44" 3 "45-54" 3 "55-65"
label values age_group age_group

* Dummy of above high school education
/* educlvl2: Educational attainment (8 categories age 6+) */
gen high_educ=0 if educlvl2<=6
replace high_educ=1 if educlvl2==7 | educlvl2==8
label var high_educ "=1 if above high school"

* Employment
/* crwrkstsr2: Work status during ref. week, extend. def. (search required) */
gen employed=1 if crwrkstsr2==1
replace employed=0 if crwrkstsr2==2 | crwrkstsr2==3
label var employed "=1 if employed"

* Employment category
/* crempstp: Employment status in prim job (ref. 1-week)
	1=Wage employee
	2=Employer
	3=Self-employed
	4=Unpaid family workers */
gen empl_cat=crempstp
label var empl_cat "Employment category"
label define empl_cat 1 "Wage employee" 2 "Employer" 3 "Self-employed" 4 "Unpaid family worker"
label values empl_cat empl_cat

gen wage_employee=1 if empl_cat==1
replace wage_employee=0 if empl_cat!=1 & empl_cat!=.
label var wage_employee "=1 if wage employee"

* Occupation (1 digit)
/* crocp1d: Occup. of prim. job (1-digit ref. 1-week)
	1=Managers
	2=Professionals
	3=Technicians and associate professionals
	4=Clerical support workers
	5=Service and sales workers
	6=Skilled agricultural, forestry and fish
	7=Craft and related trades workers
	8=Plant and machine operators, and assemb
	9=Elementary occupations */
ren crocp1d occup
label var occup "Occupation at 1 digit"

* Economic sector
/* crecac1d: Economic activity of prim. job (1-digit) (ref. 1-week)
	0=Agriculture, forestry and fishing	
	1=Mining and quarrying	
	2=Manufacturing	
	3=Electricity,gas,steam and air conditi	
	4=Water supply;sewage,waste management	
	5=Construction	
	6=Wholesale and retail trade; repair of	
	7=Transportation and storage	
	8=Accomodation and food service activit	
	9=Information and communication	
	10=Financial and insurance activities	
	11=Real estate activities	
	12=Professional, scientific and technica	
	13=Administrative and support service ac	
	14=Public administration and defense; co	
	15=Education	
	16=Human health and social work activiti	
	17=Arts, entertainment and recreation	
	18=other service activities	
	19=Activities of households as employers */
ren sector sector_survey
gen sector=crecac1d
label var sector "Economic sector 1 digit"

* Formality
/* crformal: Formality of prim. job (ref. 1-Week) 
   v629: Do you have social insurance connected to this job? */
gen formal_survey=crformal
gen formal=1 if v629==1
replace formal=0 if v629==2
label var formal_survey "Formality of primary job - Defined as in survey"
label var formal "Has social insurance at work"

* Place of work
/* v663: Describe your place of work
   1=Own home */
gen place_work=v663

gen place_work_home=1 if v663==1
replace place_work_home=0 if v663!=1 & v663!=98 & v663!=.

*	Reverse order
gen noplace_work_home=1 if place_work_home==0
replace noplace_work_home=0 if place_work_home==1

* ICT at home
/* h235: Does your family own smart phone or mobile phone?
   h236: Does your family own desktop computer? 
   h237: Does your family own notebook, laptop or tablet computer? 
   h238: Does your family own wireless internet router? */
gen mobile_home=1 if h235==1
replace mobile_home=0 if h235==2
label var mobile_home "Own a mobile phone - Hhld level"

gen comp_home=1 if  h236==1 |  h237==1
replace comp_home=0 if  h236==2 &  h237==2
label var comp_home "Own a computer - Hhld level"

gen internet_home=1 if h238==1
replace internet_home=0 if h238==2
label var internet_home "Internet connection - Hhld level"

/* v1201_3: Do you own a mobile phone?
	1=Yes, with internet connection
	2=Yes, without internet connection
	3=No */
gen mobile_indiv=1 if v1201_3==1 | v1201_3==2
replace mobile_indiv=0 if v1201_3==3
label var mobile_indiv "Own a mobile phone - Individual level"

gen internet_indiv=1 if v1201_3==1 | internet_home==1
replace internet_indiv=0 if (v1201_3==2 | v1201_3==3) & internet_home==0
label var internet_indiv "Access to internet - Individual level"

*	Reverse order
gen nointernet_indiv=1 if internet_indiv==0
replace nointernet_indiv=0 if internet_indiv==1

* Sample 
gen sample=1 if age>=16 & age<=64 & employed==1 
replace sample=. if occup==. | sector==. | educ_level==. | female==.
keep if sample==1

*********************************************************************

* Physically effort and manual skills variables 
/* v615_3: Does your job require physical fitness?
   v607: Does your job require any technical skills?
   v609: For craftsmen, what is the level of your skill? (If v607==1) */
gen physical_skills=1 if v615_3==1
replace physical_skills=0 if v615_3==2
label var physical_skills "Job require physical fitness"

gen manual=1 if v609!=.
replace manual=0 if v609==. | v607==2
label var manual "Craft-related job"

* ICT variables
/* v615_4: Does your job require computer skills? 
   v616: Do you use a computer in your work? And if so is this computer connected to the internet? 
	1=Yes, connected to the internet
	2=Yes, not connected to the internet
	3=No */
gen comp_skills=1 if v615_4==1
replace comp_skills=0 if v615_4==2

gen use_comp=1 if v616==1 | v616==2
replace use_comp=0 if v616==3

gen internet=1 if v616==1
replace internet=0 if v616==2 | v616==3

*	Reverse order
gen nocomp_skills=1 if comp_skills==0
replace nocomp_skills=0 if comp_skills==1

gen nouse_comp=1 if use_comp==0
replace nouse_comp=0 if use_comp==1

gen nointernet=1 if internet==0
replace nointernet=0 if internet==1

* Social interaction variables
/* v605: Does your job require supervising others? 
	1=Yes
	2=No */ 
gen supervise=1 if v605==1
replace supervise=0 if v605==2
label var supervise "Job requires supervising others"

* Corrects sample
replace sample=. if physical_skills==. | manual==. | comp_skills==. | nouse_comp==. | nointernet==. | supervise==. | nointernet_indiv==. 
keep if sample==1

* Adjusts weight so each country has equal weight
ren weight weight_survey
sum weight_survey 
loc sum=r(sum)
gen weight=weight_survey/`sum'
sum weight

* Saves 
capture drop country
gen country=3
gen country_code="TUN"
keep country_code country weight weight_survey age age_group female occup sector empl_cat formal place_work_home noplace_work_home physical_skills manual use_comp internet nouse_comp nointernet supervise internet_indiv nointernet_indiv high_educ wage_employee
save "`base_out'", replace
